<?php

$connect = new mysqli("localhost", "root", "", "exmount");